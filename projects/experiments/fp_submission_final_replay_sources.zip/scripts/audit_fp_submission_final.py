#!/usr/bin/env python3
"""Independent read-only aggregation of the frozen offline confirmation.

No model, optimizer, search primitive, or original analysis routine is imported.
Bootstrap intervals remain the preregistered estimator's saved marginal CIs;
this independently checks every point estimate and exact multiplicity test.
"""
from collections import defaultdict
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

ARMS = ('A', 'B', 'C', 'D', 'E', 'N', 'P')
ACTIONS = ('GA', 'LS', 'VND')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def average_precision(labels, scores):
    positives = sum(labels)
    if not positives:
        return 0.
    buckets = defaultdict(list)
    for label, score in zip(labels, scores):
        buckets[float(score)].append(int(label))
    seen = positive_seen = 0
    ap = 0.
    for score in sorted(buckets, reverse=True):
        group = buckets[score]
        seen += len(group)
        increment = sum(group)
        positive_seen += increment
        ap += increment/positives*positive_seen/seen
    return float(ap)


def signed_rank(values):
    data = np.asarray([float(v) for v in values if abs(v) > 1e-12])
    if not len(data):
        return 1.
    magnitudes = np.abs(data)
    ranks = [int(2*np.sum(magnitudes < v)+np.sum(magnitudes == v)+1) for v in magnitudes]
    weights = np.asarray([1], dtype=np.int64)
    for rank in ranks:
        polynomial = np.zeros(rank+1, dtype=np.int64)
        polynomial[0] = polynomial[-1] = 1
        weights = np.convolve(weights, polynomial)
    target = abs(sum(rank*(1 if value > 0 else -1) for rank, value in zip(ranks, data)))
    total = sum(ranks)
    extreme = sum(int(count) for i, count in enumerate(weights) if abs(2*i-total) >= target)
    return float(extreme/2**len(data))


def holm(records):
    running = 0.
    for rank, row in enumerate(sorted(records, key=lambda r: r['p'])):
        running = max(running, min(1., (len(records)-rank)*row['p']))
        row['holm_p'] = running


def per_trajectory(predictions, expected_states):
    assert len(predictions) == expected_states*3*5
    trajectories, states = defaultdict(list), defaultdict(list)
    seen = set()
    for row in predictions:
        identity = tuple(row[k] for k in ('instance', 'trajectory_id', 'state_id', 'action', 'repeat'))
        assert identity not in seen
        seen.add(identity)
        assert row['repeat'] in range(5)
        assert row['improved'] == bool(row['gain'] > 1e-12)
        assert row['gain'] >= -1e-10
        trajectories[row['instance'], row['trajectory_id']].append(row)
        states[row['instance'], row['trajectory_id'], row['state_id']].append(row)
    assert len(states) == expected_states and len(trajectories) == 400
    assert len({r['instance'] for r in predictions}) == 20
    grouped = defaultdict(lambda: defaultdict(list))
    choices = {a: {b: 0 for b in ACTIONS} for a in ARMS}
    state_decisions = {}
    for (instance, trajectory), rows in sorted(trajectories.items()):
        local_states = defaultdict(list)
        for row in rows:
            local_states[row['state_id']].append(row)
        for state_rows in local_states.values():
            assert {(r['action'], r['repeat']) for r in state_rows} == {(a, k) for a in ACTIONS for k in range(5)}
        for arm in ARMS:
            scores = [r['probabilities'][arm] for r in rows]
            labels = [int(r['improved']) for r in rows]
            selected, oracle = [], []
            for state_id, state_rows in local_states.items():
                probabilities = [np.mean([r['probabilities'][arm] for r in state_rows if r['action'] == a]) for a in ACTIONS]
                actual = [float(np.mean([r['gain'] for r in state_rows if r['action'] == a])) for a in ACTIONS]
                index = max(range(3), key=lambda j: probabilities[j])
                choices[arm][ACTIONS[index]] += 1
                selected.append(actual[index]); oracle.append(max(actual))
                state_decisions[instance, trajectory, state_id, arm] = (ACTIONS[index], actual[index])
            grouped[instance][arm].append({'ap': average_precision(labels, scores),
                'brier': float(np.mean([(s-y)**2 for s, y in zip(scores, labels)])),
                'selected_gain': float(np.mean(selected)),
                'regret': float(np.mean(np.asarray(oracle)-selected))})
    macro = {a: {m: float(np.mean([np.mean([r[m] for r in grouped[i][a]]) for i in grouped]))
                 for m in ('ap', 'brier', 'selected_gain', 'regret')} for a in ARMS}
    return grouped, choices, macro, state_decisions


def comparison(grouped, window, comparator, metric):
    sign = -1 if metric == 'brier' else 1
    differences = {instance: float(np.mean([sign*(a[metric]-b[metric]) for a, b in zip(rows['E'], rows[comparator])]))
                   for instance, rows in sorted(grouped.items())}
    return {'window': window, 'comparator': comparator, 'metric': metric,
            'mean_difference': float(np.mean(list(differences.values()))),
            'p': signed_rank(differences.values()), 'instance_differences': differences}


def verify(input_path, bundle_path, fit_receipt_path):
    result = json.loads(Path(input_path).read_text())
    bundle = json.loads(Path(bundle_path).read_text())
    fit_receipt = json.loads(Path(fit_receipt_path).read_text())
    bundle_hash = sha(bundle_path)
    assert result['model_bundle_sha256'] == bundle_hash == fit_receipt['bundle_sha256']
    assert bundle['status'] == 'FROZEN_FULL_DEVELOPMENT_ONLY_MODELS'
    assert fit_receipt['status'] == 'PASS_ALL7_FULL_DEVELOPMENT_FITS'
    assert len(bundle['training_instances']) == 16
    assert fit_receipt['final_outcomes_read'] == 0
    widths = dict(A=9, B=24, C=34, D=36, E=48, N=48, P=48)
    for arm in ARMS:
        classifier = bundle['classifiers'][arm]
        dimension = 3+3*widths[arm]
        assert len(classifier['weights']) == dimension+1
        assert len(classifier['center']) == len(classifier['scale']) == dimension
        assert np.all(np.isfinite(classifier['weights']))
        assert np.all(np.isfinite(classifier['center']))
        assert np.all(np.asarray(classifier['scale']) >= 1e-8)
        assert classifier['l2'] == 1. and classifier['converged']
        assert classifier['independent_gradient_inf'] <= 1e-7
        assert np.isfinite(classifier['independent_loss'])
        assert classifier['finite_difference']['passed']
        assert len(classifier['finite_difference']['directions']) == 6
        assert all(r['absolute_error'] <= 2e-7 for r in classifier['finite_difference']['directions'])
        assert classifier['independent_gradient_inf'] == fit_receipt['classifiers'][arm]['independent_gradient_inf']
    assert len(bundle['negative_control_training_pool_x']) == 17280
    assert np.asarray(bundle['negative_control_training_pool_x']).shape == (17280, 4)
    for action in ACTIONS:
        model = bundle['action_fp']['maps'][action]
        assert np.asarray(model['A']).shape == (4, 4)
        assert np.asarray(model['c']).shape == (4,)
        assert np.all(np.isfinite(model['A'])) and np.all(np.isfinite(model['c']))
        assert np.all(np.asarray(model['scale']) >= 1e-6)
        assert model['support_radius'] >= 0
    assert result['status'] == 'FINAL_FROZEN_OFFLINE_CONFIRMATION_COMPLETE'
    assert result['model_refits_during_confirmation'] == 0
    window_data = {}
    maximum_metric_error = 0.
    decisions = {}
    action_counts = {}
    for window, expected in [('atomic', 3600), ('fair480', 1200)]:
        assert not ({r['instance'] for r in result['predictions'][window]}&set(bundle['training_instances']))
        grouped, choices, macro, states = per_trajectory(result['predictions'][window], expected)
        window_data[window] = grouped
        action_counts[window] = choices
        decisions[window] = states
        for arm in ARMS:
            for metric, value in macro[arm].items():
                error = abs(value-result[f'{window}_summary']['macro_instance_trajectory_metrics'][arm][metric])
                maximum_metric_error = max(maximum_metric_error, error)
                assert error < 1e-12
            assert choices[arm] == result[f'{window}_summary']['action_counts'][arm]
    predecision_scores = {}
    for row in result['predictions']['atomic']:
        identity = tuple(row[k] for k in ('instance', 'trajectory_id', 'state_id', 'action'))
        if identity in predecision_scores:
            assert predecision_scores[identity] == row['probabilities']
        predecision_scores[identity] = row['probabilities']
    for row in result['predictions']['fair480']:
        identity = tuple(row[k] for k in ('instance', 'trajectory_id', 'state_id', 'action'))
        assert predecision_scores[identity] == row['probabilities']
    # Fair480 must use the exact same action choice at every corresponding
    # state: no window-specific refit, probability calibration or tuning.
    for identity, (action, _) in decisions['fair480'].items():
        assert action == decisions['atomic'][identity][0]
    comparisons = [comparison(window_data['atomic'], 'atomic', c, m) for c in ('C', 'N', 'P')
                   for m in ('ap', 'brier', 'selected_gain')]
    comparisons += [comparison(window_data['fair480'], 'fair480', c, 'selected_gain') for c in ('C', 'N', 'P')]
    holm(comparisons)
    for row, saved in zip(comparisons, result['primary_comparisons']):
        assert (row['window'], row['comparator'], row['metric']) == (saved['window'], saved['comparator'], saved['metric'])
        for metric in ('mean_difference', 'p', 'holm_p'):
            assert abs(row[metric]-saved[metric]) < 1e-12
        for instance, value in row['instance_differences'].items():
            assert abs(value-saved['instance_differences'][instance]) < 1e-12
    dynamic = result['dynamics']
    grouped = defaultdict(list)
    for row in dynamic['trajectory_errors']:
        grouped[row['instance']].append(row)
    assert len(grouped) == 20 and sum(map(len, grouped.values())) == 400
    dynamic_comparisons = []
    for action in ACTIONS:
        for baseline in ('pooled', 'identity'):
            means = [np.mean([r['errors'][action][baseline]-r['errors'][action]['conditioned'] for r in rows]) for _, rows in sorted(grouped.items())]
            dynamic_comparisons.append({'action': action, 'comparator': baseline,
                'mean_error_reduction': float(np.mean(means)), 'p': signed_rank(means)})
    holm(dynamic_comparisons)
    for row, saved in zip(dynamic_comparisons, dynamic['comparisons']):
        assert (row['action'], row['comparator']) == (saved['action'], saved['comparator'])
        for metric in ('mean_error_reduction', 'p', 'holm_p'):
            assert abs(row[metric]-saved[metric]) < 1e-12
    changed = {}
    for window, states in decisions.items():
        count = better = worse = same = 0
        for (instance, trajectory, state, arm), (action, gain) in states.items():
            if arm != 'E':
                continue
            baseline, baseline_gain = states[instance, trajectory, state, 'C']
            if action != baseline:
                count += 1
                better += gain > baseline_gain+1e-12
                worse += gain < baseline_gain-1e-12
                same += abs(gain-baseline_gain) <= 1e-12
        changed[window] = {'changed': int(count), 'better': int(better), 'worse': int(worse), 'same': int(same)}
    return {'status': 'PASS_ALL_FINAL_METRIC_AND_MULTIPLICITY_CHECKS',
        'input': str(input_path), 'input_sha256': sha(input_path),
        'frozen_bundle_sha256': bundle_hash,
        'full_development_fit_receipt_sha256': sha(fit_receipt_path),
        'bundle_parameter_and_numerical_receipt_consistency': 'PASS_ALL7; no fresh training objective recomputation claimed',
        'model_or_search_imports': 0, 'verified_counts': {'instances': 20, 'trajectories': 400,
            'atomic_states': 3600, 'atomic_branches': 54000, 'fair480_states': 1200, 'fair480_branches': 18000},
        'maximum_macro_metric_error': maximum_metric_error,
        'primary_family12': comparisons, 'dynamics_family6': dynamic_comparisons,
        'action_counts': action_counts, 'E_vs_C_changed_choices': changed,
        'scope': 'Independent prediction aggregation and polynomial exact signed-rank/Holm checks; saved bootstrap CI endpoints not independently recomputed.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True)
    parser.add_argument('--bundle', required=True)
    parser.add_argument('--fit-receipt', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    if Path(args.output).exists():
        raise ValueError('Never overwrite audit receipt')
    result = verify(args.input, args.bundle, args.fit_receipt)
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'status': result['status'], 'verified_counts': result['verified_counts']}))


if __name__ == '__main__':
    main()
