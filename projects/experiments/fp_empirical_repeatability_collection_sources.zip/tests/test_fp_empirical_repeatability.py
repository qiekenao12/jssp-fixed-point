"""Numerical work-window tests; operators themselves remain unchanged."""
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.fp_empirical_repeatability import work_window
from run_fp_action_diagnostics import Protocol, fingerprint
from run_ablation_test import parse_jobshop1
from run_orchestration_baselines import make_instance
from run_trigger_comparison import rng_stream
from tools.executor import Population, Executor
from tools.meta_scheduler import MetaScheduler
from tools.paper_q import QueryMeter, QExecutor
from scripts.audit_fp_action_data import dag_makespan


class RepeatabilityWindowTests(unittest.TestCase):
    def initial(self):
        data = parse_jobshop1(str(ROOT/'jobshop1.txt'))['ft06']
        instance = make_instance(data)
        protocol = Protocol(population=12, generations=40, snapshot_interval=20)
        meter = QueryMeter(10000)
        executor = QExecutor(instance, meter)
        with rng_stream(7305), meter.activate():
            individuals = MetaScheduler(instance)._init_population(protocol.population)
            pop = Population(individuals, executor.evaluate_population(individuals))
        return data, instance, pop, protocol

    def test_query_ceiling_uses_real_operators_and_preserves_saved_population(self):
        data, instance, pop, protocol = self.initial()
        frozen = fingerprint(pop)
        for action in ('GA', 'LS', 'VND'):
            outcome = work_window(instance, pop, action, 508, 20, protocol,
                                  pop.best_fitness, ceiling=60)
            self.assertEqual(fingerprint(pop), frozen)
            self.assertIn(outcome['queries'], [59, 60])
            self.assertEqual(sum(c['queries'] for c in outcome['primitive_calls']), outcome['queries'])
            self.assertEqual(dag_makespan(outcome['best_chromosome'], data), outcome['end_makespan'])
            self.assertLessEqual(outcome['end_makespan'], pop.best_fitness)

    def test_pure_ga_completes_whole_generations_without_any_ls(self):
        _, instance, pop, protocol = self.initial()
        with patch.object(Executor, 'local_search_improved', side_effect=AssertionError('LS in GA')), \
             patch.object(Executor, 'critical_path_local_search', side_effect=AssertionError('LS in GA')), \
             patch.object(Executor, 'local_search_vnd', side_effect=AssertionError('VND in GA')):
            outcome = work_window(instance, pop, 'GA', 508, 20, protocol, pop.best_fitness, ceiling=60)
        self.assertEqual(outcome['queries'], 60)
        self.assertEqual(outcome['elapsed_ga_generations'], 5)
        self.assertTrue(all(c['termination'] == 'natural_return' and c['queries'] == 12
                            for c in outcome['primitive_calls']))

    def test_ls_records_final_partial_primitive_without_padding(self):
        _, instance, pop, protocol = self.initial()
        outcome = work_window(instance, pop, 'LS', 508, 20, protocol, pop.best_fitness, ceiling=60)
        self.assertEqual(outcome['queries'], 60)
        self.assertEqual(len(outcome['primitive_calls']), 1)
        self.assertEqual(outcome['primitive_calls'][0]['termination'], 'request_boundary_truncation')


if __name__ == '__main__':
    unittest.main()
