"""Semantic, grouping, leakage and statistical tests, not quality assertions."""
from pathlib import Path
import sys
import unittest
import copy
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT/'src'))
from tools.action_fp import ActionFPModel, ACTIONS, pure_window, weighted_norm, collapsed_transitions
from analyze_fp_action_diagnostics import (Logistic, average_precision, audit_records,
    feature_matrix, train_predict, trajectory_metrics, m2_gate, signal_rows, common_context, VARIANTS)


def synthetic(instances=7, states=8, repeats=2):
    rng = np.random.default_rng(93)
    records = []
    for instance in range(instances):
        for state in range(states):
            x = np.r_[rng.uniform(.8, 1.2), rng.uniform(1.2, 1.6), rng.uniform(.01, .2), rng.uniform(.1, .9)]
            for j, action in enumerate(ACTIONS):
                movement = np.array([-.001*(j+1)*x[3], -.002*(j+1), -.001, -.01*j])
                for repeat in range(repeats):
                    end = x + movement
                    gain = -movement[0]
                    records.append({'instance': f'i{instance}', 'trajectory_id': f'i{instance}:0',
                        'state_id': f's{state}', 'action': action, 'repeat': repeat,
                        'start_x': x.tolist(), 'end_x': end.tolist(),
                        'gain': float(gain), 'improved': bool(gain > 0),
                        'window': {'unit': 'atomic_action_application', 'span': 1, 'action_sequence': [action]},
                        'real_stagnant_generations': state,
                        'original_fp': {'residual': .01, 'model_ready': True}})
    return records


class ActionFPTests(unittest.TestCase):
    def test_recovers_action_affine_maps_and_defines_weighted_residual(self):
        records = synthetic()
        model = ActionFPModel(ridge=1e-8).fit(records)
        x = [.9, 1.3, .1, .5]
        signal = model.predict(x, 'VND')
        self.assertTrue(signal.model_ready)
        self.assertEqual(signal.training_transitions, 56)  # repeats collapsed
        self.assertAlmostEqual(signal.predicted_state[0], .8985, places=7)
        self.assertAlmostEqual(signal.predicted_state[1], 1.294, places=7)
        self.assertAlmostEqual(signal.residual, weighted_norm(np.array(signal.predicted_state)-x))
        self.assertGreater(signal.reliability, .99)
        self.assertLess(signal.prediction_error, 1e-6)

    def test_sparse_model_cannot_claim_high_confidence(self):
        model = ActionFPModel().fit(synthetic(instances=2))
        signal = model.predict([1, 1.2, .1, .5], 'GA')
        self.assertFalse(signal.model_ready)
        self.assertEqual(signal.reliability, 0)
        self.assertIsNone(signal.prediction_error)
        self.assertEqual(signal.residual, 0.)

    def test_pure_atomic_window_enforced(self):
        row = synthetic()[0]
        row['window']['action_sequence'] = ['GA', 'VND']
        with self.assertRaisesRegex(ValueError, 'pure single'):
            pure_window(row)
        row['window']['action_sequence'] = ['GA']
        row['window']['span'] = 5
        with self.assertRaises(ValueError):
            collapsed_transitions([row])

    def test_group_audit_rejects_missing_action_or_changed_state(self):
        rows = synthetic()
        self.assertEqual(audit_records(rows)['instances'], 7)
        with self.assertRaisesRegex(ValueError, 'identical repeat'):
            audit_records(rows[1:])
        bad = copy.deepcopy(rows)
        bad[1]['start_x'][0] += .1
        with self.assertRaisesRegex(ValueError, 'identical states'):
            audit_records(bad)

    def test_heldout_future_outcomes_do_not_change_predictions(self):
        rows = synthetic(instances=8, states=12, repeats=1)
        train = [r for r in rows if r['instance'] != 'i7']
        held = [r for r in rows if r['instance'] == 'i7']
        predicted, errors, models, _ = train_predict(train, held, {'ridge': .001, 'l2': 1.})
        self.assertTrue(all(model['model_ready'] for model in models.values()))
        self.assertTrue(all(row['signal']['model_ready'] for row in errors))
        self.assertTrue(all(row['signal']['residual'] > 0 for row in errors))
        changed = copy.deepcopy(held)
        for row in changed:
            row['end_x'] = [9., 9., 9., 9.]
            row['gain'], row['improved'] = 0., False
        again, _, _, _ = train_predict(train, changed, {'ridge': .001, 'l2': 1.})
        for arm in predicted:
            np.testing.assert_array_equal(predicted[arm], again[arm])
        with self.assertRaisesRegex(ValueError, 'overlap'):
            train_predict(train, train[:3], {'ridge': .001, 'l2': 1.})

    def test_per_state_memoization_preserves_every_signal_error_and_random_control(self):
        rows = synthetic(instances=8, states=12)
        train = [r for r in rows if r['instance'] != 'i7']
        held = [r for r in rows if r['instance'] == 'i7']
        cached = signal_rows(train, held, .001)
        uncached = signal_rows(train, held, .001, reuse_identical_states=False)
        for a, b in zip(cached[0], uncached[0]):
            np.testing.assert_array_equal(a[0], b[0])
            np.testing.assert_array_equal(a[1], b[1])
        self.assertEqual(cached[1], uncached[1])
        self.assertEqual(cached[2], uncached[2])
        np.testing.assert_array_equal(cached[3], uncached[3])

    def test_identical_causal_phase_and_main_gain_context_in_every_arm(self):
        row = synthetic(states=1, repeats=1)[0]
        row.update(generation=90, recent_real_gains=[99., 0., .1, 0., .2, .3, 0.])
        expected = [.5, .1, .5, 0.]
        np.testing.assert_allclose(common_context(row), expected)
        self.assertTrue(np.array_equal(common_context({}), np.zeros(4)))
        signals = [(np.zeros(5), np.zeros(9))]
        for arm in VARIANTS:
            matrix = feature_matrix([row], signals, arm, np.zeros((1, 14)))
            width = (matrix.shape[1]-3)//3
            np.testing.assert_allclose(matrix[0, 3+width-4:3+width], expected)
            np.testing.assert_array_equal(matrix[0, 3+width:], np.zeros(2*width))

    def test_negative_control_uses_one_candidate_feature_vector_per_saved_state(self):
        rows = synthetic(states=5)
        train = [r for r in rows if r['instance'] != 'i6']
        held = [r for r in rows if r['instance'] == 'i6']
        _, _, _, controls = signal_rows(train, held, .001)
        for state in {r['state_id'] for r in held}:
            indices = [i for i, row in enumerate(held) if row['state_id'] == state]
            for i in indices[1:]:
                np.testing.assert_array_equal(controls[indices[0]], controls[i])

    def test_logistic_probabilities_and_ap_ties(self):
        x = np.tile([[-1.], [1.]], (30, 1))
        y = np.tile([0., 1.], 30)
        model = Logistic(l2=1).fit(x, y)
        probabilities = model.predict([[-1.], [1.]])
        self.assertLess(probabilities[0], .1)
        self.assertGreater(probabilities[1], .9)
        self.assertAlmostEqual(average_precision([0, 1, 0, 1], [.5]*4), .5)
        self.assertEqual(average_precision([0, 0], [1, 0]), 0.)
        self.assertEqual(average_precision([1, 0], [1, 0]), 1.)

    def test_gate_requires_all_information_and_gain_endpoints(self):
        comparisons = []
        for comparator in ('B', 'STATE_QUADRATIC', 'PERMUTED_FP'):
            for metric in ('ap', 'brier', 'selected_gain'):
                comparisons.append({'comparator': comparator, 'metric': metric,
                    'mean_difference': 1., 'hierarchical_bootstrap_95ci': [.1, 2.], 'holm_p': .01})
        summary = {'comparisons': comparisons}
        self.assertFalse(m2_gate(summary, independent_validation=False)['pass'])
        self.assertTrue(m2_gate(summary, independent_validation=True)['pass'])
        comparisons[1]['hierarchical_bootstrap_95ci'][0] = -.01
        self.assertFalse(m2_gate(summary, independent_validation=True)['pass'])
        comparisons[1]['hierarchical_bootstrap_95ci'][0] = .1
        comparisons[5]['holm_p'] = .6
        self.assertFalse(m2_gate(summary, independent_validation=True)['pass'])


if __name__ == '__main__':
    unittest.main()
