"""Independent isolation and pure-action tests for the M2 diagnostic harness."""
from dataclasses import replace
from pathlib import Path
import random
import sys
import unittest
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'src'))
from run_fp_action_diagnostics import (ACTIONS, Protocol, branch, clone,
    fingerprint, parameters, run_trajectory, stream_seed)
from run_ablation_test import parse_jobshop1
from run_orchestration_baselines import make_instance
from run_trigger_comparison import rng_stream
from tools.executor import Executor, Population
from tools.meta_scheduler import MetaScheduler
from tools.paper_q import QExecutor, QueryMeter
from scripts.audit_fp_action_data import dag_makespan, diversity


def remove_clock(value):
    if isinstance(value, dict):
        return {k: remove_clock(v) for k, v in value.items()
                if 'seconds' not in k and 'elapsed' not in k}
    if isinstance(value, list):
        return [remove_clock(item) for item in value]
    return value


class FPActionDiagnosticsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = parse_jobshop1(str(ROOT / 'jobshop1.txt'))['ft06']
        cls.protocol = Protocol(population=12, generations=40,
                                snapshot_interval=20, repeats=1,
                                local_iterations=15, main_ls_iterations=8)

    def initial(self):
        instance = make_instance(self.data)
        meter = QueryMeter(10000)
        executor = QExecutor(instance, meter)
        with rng_stream(745), meter.activate():
            individuals = MetaScheduler(instance)._init_population(self.protocol.population)
            population = Population(individuals, executor.evaluate_population(individuals))
        return instance, population

    def test_independent_DAG_checker_matches_hand_worked_machine_orders(self):
        data = {'num_jobs': 2, 'num_machines': 2,
                'processing_times': [[2, 3], [2, 1]],
                'machine_sequences': [[0, 1], [1, 0]]}
        self.assertEqual(dag_makespan([0, 1, 0, 1], data), 5)
        self.assertEqual(dag_makespan([0, 0, 1, 1], data), 8)
        with self.assertRaises(ValueError):
            dag_makespan([0, 0, 0, 1], data)
        with self.assertRaises(ValueError):
            dag_makespan([0, 1, 0.0, 1], data)

    def test_independent_diversity_count_formula_matches_pairwise_example(self):
        population = np.array([[0, 1], [0, 1], [1, 0]])
        self.assertAlmostEqual(diversity(population, 2), 2/3)
        self.assertEqual(diversity(population[:1], 2), 0)

    def test_collecting_diagnostics_preserves_entire_neutral_trajectory(self):
        before = run_trajectory('ft06', 0, self.data, self.protocol, collect=False)
        after = run_trajectory('ft06', 0, self.data, self.protocol, collect=True)
        for key in ('initial_fingerprint', 's0', 'snapshots', 'main_final_makespan',
                    'main_final_fingerprint', 'main_queries', 'main_decodes',
                    'main_incumbent_trace'):
            self.assertEqual(remove_clock(before[key]), remove_clock(after[key]), key)
        self.assertEqual(before['records'], [])
        self.assertEqual(len(after['records']), 2 * 3)
        self.assertGreater(after['diagnostic_queries'], 0)
        self.assertEqual(after['diagnostic_queries'], sum(r['queries'] for r in after['records']))
        self.assertTrue(all(not s['original_fp']['model_ready'] for s in after['snapshots']))

    def test_branch_order_does_not_change_counterfactual_results(self):
        forward = run_trajectory('ft06', 1, self.data, self.protocol,
                                 action_order=ACTIONS)
        reverse = run_trajectory('ft06', 1, self.data, self.protocol,
                                 action_order=tuple(reversed(ACTIONS)))
        sortkey = lambda r: (r['state_id'], r['action'], r['repeat'])
        self.assertEqual(remove_clock(sorted(forward['records'], key=sortkey)),
                         remove_clock(sorted(reverse['records'], key=sortkey)))
        self.assertEqual(forward['main_final_fingerprint'], reverse['main_final_fingerprint'])
        self.assertEqual(remove_clock(forward['main_incumbent_trace']),
                         remove_clock(reverse['main_incumbent_trace']))

    def test_ga_branch_cannot_execute_ls_or_vnd(self):
        instance, population = self.initial()
        with patch.object(Executor, 'local_search_improved', side_effect=AssertionError('LS in GA')), \
             patch.object(Executor, 'critical_path_local_search', side_effect=AssertionError('CP-LS in GA')), \
             patch.object(Executor, 'local_search_vnd', side_effect=AssertionError('VND in GA')):
            result = branch(instance, population, 'GA', 493, 20,
                            self.protocol, population.best_fitness)
        self.assertEqual(result['window']['action_sequence'], ['GA'])
        self.assertEqual(result['elapsed_ga_generations'], 1)
        self.assertEqual(set(k for k, v in result['phase_queries'].items() if v), {'ga'})

    def test_ls_branch_cannot_execute_ga_or_vnd(self):
        instance, population = self.initial()
        with patch.object(Executor, 'evolve_generation', side_effect=AssertionError('GA in LS')), \
             patch.object(Executor, 'local_search_vnd', side_effect=AssertionError('VND in LS')), \
             patch.object(QExecutor, 'search_candidate', side_effect=AssertionError('VND adapter in LS')):
            result = branch(instance, population, 'LS', 493, 20,
                            self.protocol, population.best_fitness)
        self.assertEqual(result['window']['action_sequence'], ['LS'])
        self.assertEqual(result['elapsed_ga_generations'], 0)
        self.assertEqual(set(k for k, v in result['phase_queries'].items() if v), {'ls'})

    def test_clone_and_each_branch_preserve_saved_population_and_rng(self):
        instance, population = self.initial()
        other = clone(population)
        for source, target in zip(population.individuals, other.individuals):
            self.assertFalse(np.shares_memory(source, target))
        other.individuals[0][0] = -1
        self.assertNotEqual(other.individuals[0][0], population.individuals[0][0])
        before = fingerprint(population)
        for action in ACTIONS:
            python_state, numpy_state = random.getstate(), np.random.get_state()
            result = branch(instance, population, action, 765, 20,
                            self.protocol, population.best_fitness)
            self.assertEqual(fingerprint(population), before)
            self.assertEqual(random.getstate(), python_state)
            now = np.random.get_state()
            self.assertEqual(now[0], numpy_state[0])
            np.testing.assert_array_equal(now[1], numpy_state[1])
            self.assertEqual(now[2:], numpy_state[2:])
            self.assertLessEqual(result['queries'], self.protocol.action_query_cap)
            self.assertEqual(sum(result['phase_queries'].values()), result['queries'])

    def test_query_cap_returns_feasible_incumbent_for_every_action(self):
        instance, population = self.initial()
        # GA and ordinary LS must complete a pure atomic application. Their
        # configured cap must cover the nominal action; only VND has a defined
        # interruptible bounded incumbent contract.
        tiny = replace(self.protocol, action_query_cap=30)
        for action in ACTIONS:
            before = fingerprint(population)
            result = branch(instance, population, action, 777, 20,
                            tiny, population.best_fitness)
            self.assertLessEqual(result['queries'], tiny.action_query_cap)
            self.assertLessEqual(result['end_makespan'], population.best_fitness)
            self.assertEqual(result['termination_reason'] == 'query_cap',
                             result['queries'] == tiny.action_query_cap)
            self.assertEqual(fingerprint(population), before)

    def test_insufficient_nominal_cap_is_rejected_before_partial_action(self):
        with self.assertRaises(ValueError):
            replace(self.protocol, action_query_cap=2)
        with self.assertRaises(ValueError):
            replace(self.protocol, action_query_cap=80, local_iterations=100)


if __name__ == '__main__':
    unittest.main()
