#!/usr/bin/env python3
"""Complete frozen M2 validation and reports. Never launches M3 or locked tests."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
STATE = ROOT / 'projects/experiments/fp_v2_execution_progress.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def note(stage, **values):
    state = json.loads(STATE.read_text()) if STATE.exists() else {'history': []}
    event = {'utc': datetime.now(timezone.utc).isoformat(), 'stage': stage, **values}
    state['history'].append(event)
    state['current_stage'] = stage
    STATE.write_text(json.dumps(state, indent=2))
    print(json.dumps(event), flush=True)


def verify():
    lock = json.loads((ROOT/'projects/experiments/fp_v2_m2_source_lock.json').read_text())
    for name, expected in lock['sources_sha256'].items():
        if sha(ROOT/name) != expected:
            raise ValueError(f'Frozen M2 source mismatch: {name}')


def run(command, logfile, env):
    verify()
    note('launch', command=command, log=logfile)
    with open(logfile, 'w') as stream:
        subprocess.run(command, cwd=ROOT, env=env, stdout=stream,
                       stderr=subprocess.STDOUT, check=True)


def main():
    env = os.environ.copy()
    env.update({k: '1' for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS')})
    development = ROOT/'projects/analysis/fp_v2_development_analysis.json'
    note('waiting_for_frozen_development_analysis')
    while True:
        verify()
        try:
            selection = json.loads(development.read_text())
            if selection['stage'] != 'development' or len(selection['configurations']) != 4:
                raise ValueError('Incomplete development selection')
            break
        except (FileNotFoundError, json.JSONDecodeError):
            time.sleep(5)
    assert not (ROOT/'results/fp_v2_validation').exists(), 'Validation must begin only after this lock'
    receipt = json.loads((ROOT/'projects/analysis/fp_action_development_independent_audit.json').read_text())
    assert receipt['status'] == 'PASS_COMPLETE'
    selected_lock = {'created_utc': datetime.now(timezone.utc).isoformat(),
        'selected_config': selection['selected_config'],
        'selected_config_index': selection['selected_config_index'],
        'selection_rule': selection['selection_rule'],
        'development_analysis_sha256': sha(development),
        'source_sha256': selection['source_sha256'],
        'before_validation_collection': True, 'validation_tuning_allowed': False,
        'locked_test_execution_allowed': False}
    path = ROOT/'projects/experiments/fp_v2_selected_configuration.json'
    assert not path.exists()
    path.write_text(json.dumps(selected_lock, indent=2))
    note('development_selected_and_frozen_before_validation', **selected_lock)
    run([sys.executable,'run_fp_action_diagnostics.py','--split','validation',
         '--runs','20','--workers','16','--output','results/fp_v2_validation'],
        '/tmp/fp_v2_validation.log',env)
    note('validation_diagnostics_complete')
    run([sys.executable,'scripts/audit_fp_action_data.py','results/fp_v2_validation',
         '--output','projects/analysis/fp_action_validation_independent_audit.json'],
        '/tmp/fp_v2_validation_audit.log',env)
    run([sys.executable,'analyze_fp_action_diagnostics.py','--development','results/fp_v2_development',
         '--validation','results/fp_v2_validation','--selection',str(development),
         '--output','projects/analysis/fp_v2_validation_analysis.json'],
        '/tmp/fp_v2_validation_analysis.log',env)
    validation = json.loads((ROOT/'projects/analysis/fp_v2_validation_analysis.json').read_text())
    note('M2_gate_evaluated', gate=validation['m2_gate'])
    run([sys.executable,'scripts/report_fp_agent_v2.py',
         '--development-audit','projects/analysis/fp_action_development_independent_audit.json',
         '--validation-audit','projects/analysis/fp_action_validation_independent_audit.json'],
        '/tmp/fp_v2_report.log',env)
    note('M2_deliverables_complete', M3='NOT_RUN', locked_tests='NOT_RUN',
         next_action='M3 may be implemented only if the predeclared M2 gate passed')


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        note('pipeline_stopped', error=f'{type(error).__name__}: {error}')
        raise
