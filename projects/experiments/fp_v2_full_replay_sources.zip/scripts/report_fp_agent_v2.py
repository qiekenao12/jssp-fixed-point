#!/usr/bin/env python3
"""Render completed, audited M2 evidence without running searches or inference.

This renderer reads saved statistics. It does not import the solver, dynamics
model, classifier, or statistical analyzer, and never selects a new model.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import statistics

ROOT = Path(__file__).resolve().parents[1]
VARIANTS = ('A', 'B', 'C', 'D', 'E', 'STATE_QUADRATIC', 'PERMUTED_FP')
ACTIONS = ('GA', 'LS', 'VND')
METRICS = ('ap', 'brier', 'selected_gain', 'action_rank', 'decision_change_vs_B')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def canonical(value, *, ensure_ascii=True):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=ensure_ascii, allow_nan=False).encode()).hexdigest()


def mean(values):
    values = list(values)
    require(bool(values), 'Cannot silently average an empty group')
    return statistics.fmean(values)


def number(value, digits=6):
    return f'{float(value):.{digits}f}' if value is not None else 'NA'


def table(headers, rows):
    def cell(value):
        return str(value).replace('|', '\\|').replace('\n', ' ')
    return '\n'.join(['| ' + ' | '.join(map(cell, headers)) + ' |',
        '| ' + ' | '.join('---' for _ in headers) + ' |'] +
        ['| ' + ' | '.join(map(cell, row)) + ' |' for row in rows]) + '\n'


def csv_write(path, rows):
    require(bool(rows), f'Empty appendix: {path}')
    with Path(path).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def size_group(operations):
    return '<=100' if operations <= 100 else '101-400' if operations <= 400 else '>400'


def load_cohort(directory, receipt_path, split, manifest):
    """Bind all saved data to a mandatory independent complete audit receipt."""
    directory = Path(directory).resolve()
    receipt = read(receipt_path)
    protocol = read(directory/'protocol.json')
    names = manifest['splits'][split]
    require(receipt['status'] == 'PASS_COMPLETE', f'{split}: formal data audit is not complete')
    require(receipt['split'] == split and receipt['instances'] == names and receipt['runs'] == 20,
            f'{split}: audit cohort differs from frozen manifest')
    require(protocol['instances'] == names and protocol['split'] == split and protocol['runs'] == 20,
            f'{split}: diagnostic protocol cohort mismatch')
    require(receipt['protocol_sha256'] == sha(directory/'protocol.json') and
            receipt['protocol_hash'] == protocol['protocol_hash'], f'{split}: protocol audit identity mismatch')
    require(canonical({k:v for k,v in protocol.items() if k != 'protocol_hash'}) == protocol['protocol_hash'],
            f'{split}: invalid protocol hash')
    require(receipt['manifest_sha256'] == sha(ROOT/'projects/experiments/fp_v2_manifest.json'),
            f'{split}: manifest audit identity mismatch')
    require(protocol['protocol']['repeats'] == 2 and protocol['protocol']['generations'] == 180 and
            protocol['protocol']['snapshot_interval'] == 20, f'{split}: action/observation settings changed')
    expected = {f'{name}_{run:02d}.json' for name in names for run in range(20)}
    require(set(receipt['trajectory_sha256']) == expected,
            f'{split}: audit does not cover all trajectory files')
    require({p.name for p in directory.glob('*.json') if p.name != 'protocol.json'} == expected,
            f'{split}: missing/extra raw trajectories')
    trajectories, branches = [], []
    for name in names:
        for run in range(20):
            path = directory/f'{name}_{run:02d}.json'
            require(sha(path) == receipt['trajectory_sha256'][path.name], f'Audited data changed: {path}')
            saved = read(path)
            require((saved['instance'], saved['run'], saved['trajectory_id']) ==
                    (name, run, f'{name}:{run}'), f'{split}: trajectory identity mismatch')
            archive = ROOT/saved['population_archive']
            require(sha(archive) == saved['population_archive_sha256'] ==
                    receipt['archive_sha256'][saved['population_archive']], 'Audited population archive changed')
            require(len(saved['records']) == 54 and len(saved['snapshots']) == 9,
                    f'{split}: incomplete action/snapshot grid')
            trajectories.append(saved)
            branches.extend(saved['records'])
    require(receipt['counts']['trajectories'] == len(names)*20 and
            receipt['counts']['snapshot_DAG_checks'] == len(names)*20*9 and
            receipt['counts']['branch_DAG_checks'] == len(names)*20*54,
            f'{split}: independent schedule audit denominator mismatch')
    branches.sort(key=lambda r:(str(r['instance']), str(r['trajectory_id']), str(r['state_id']),
                                ACTIONS.index(r['action']), int(r.get('repeat', 0))))
    return trajectories, branches, protocol, receipt


def verify_predictions(summary, predictions, rows, instances):
    expected = {(r['instance'],r['trajectory_id'],r['state_id'],r['action'],r['repeat']):r for r in rows}
    require(len(predictions) == len(expected), 'Incomplete prediction grid')
    seen = set()
    for prediction in predictions:
        key = tuple(prediction[k] for k in ('instance','trajectory_id','state_id','action','repeat'))
        require(key in expected and key not in seen, 'Missing, duplicate or unregistered prediction')
        seen.add(key)
        row = expected[key]
        require(prediction['gain'] == row['gain'] and prediction['improved'] == row['improved'] and
                prediction['start_x'] == row['start_x'], 'Prediction labels/start state differ from audited data')
        require(set(prediction['probabilities']) == set(VARIANTS), 'Incomplete feature-arm prediction grid')
        require(all(math.isfinite(v) and 0 <= v <= 1 for v in prediction['probabilities'].values()),
                'Invalid improvement probability')
    require(summary['instances'] == len(instances) and summary['trajectories'] == len(instances)*20,
            'Analysis summary cohort mismatch')
    require(len(summary['trajectory_metrics']) == len(instances)*20, 'Incomplete trajectory metrics')
    for name in instances:
        local = [r for r in summary['trajectory_metrics'] if r['instance'] == name]
        require(len(local) == 20 and len({r['trajectory_id'] for r in local}) == 20,
                'Analysis dropped or duplicated trajectory metrics')
        require(all(r['states'] == 9 and r['observations'] == 54 and set(r['variants']) == set(VARIANTS)
                    for r in local), 'Metric denominator or feature arms changed')
    expected_comparisons = {(control,metric) for control in ('B','STATE_QUADRATIC','PERMUTED_FP')
                            for metric in ('ap','brier','selected_gain')}
    require(len(summary['comparisons']) == 9 and
            {(r['comparator'],r['metric']) for r in summary['comparisons']} == expected_comparisons,
            'The registered primary nine-comparison family is incomplete')


def instance_metrics(split, summary, manifest):
    groups = defaultdict(list)
    for row in summary['trajectory_metrics']:
        groups[row['instance']].append(row)
    result = []
    for name in manifest['splits'][split]:
        rows = groups[name]
        metadata = manifest['instances'][name]
        for variant in VARIANTS:
            counts = {action:sum(r['variants'][variant]['chosen_action_counts'][action] for r in rows)
                      for action in ACTIONS}
            require(sum(counts.values()) == 180, 'Chosen actions do not cover every saved opportunity')
            result.append(dict(split=split, instance=name, family=metadata['family'],
                operations=metadata['operations'], size_group=size_group(metadata['operations']),
                variant=variant, trajectories=len(rows), decision_opportunities=180,
                **{metric:mean(r['variants'][variant][metric] for r in rows) for metric in METRICS},
                **{f'chosen_{a}':counts[a] for a in ACTIONS}))
    return result


def grouped_metrics(rows):
    output = []
    for split in ('development','validation'):
        for kind in ('family','size_group'):
            groups = defaultdict(list)
            for row in rows:
                if row['split'] == split:
                    groups[row[kind],row['variant']].append(row)
            for (group,variant), selected in sorted(groups.items()):
                output.append(dict(split=split, group_type=kind, group=group, variant=variant,
                    instances=len(selected), **{metric:mean(r[metric] for r in selected) for metric in METRICS},
                    **{f'chosen_{a}':sum(r[f'chosen_{a}'] for r in selected) for a in ACTIONS}))
    return output


def cost_and_action_rows(split, trajectories, branches, manifest):
    by_instance_action = defaultdict(list)
    branch_rows = []
    for row in branches:
        by_instance_action[row['instance'],row['action']].append(row)
        seed_text = f"20261018:{row['instance']}:{row['run']}:{row['generation']}:branch_{row['action']}_{row['repeat']}"
        seed = int.from_bytes(hashlib.sha256(seed_text.encode()).digest()[:4], 'big')
        branch_rows.append({k:row[k] for k in ('instance','trajectory_id','run','state_id','generation','action','repeat',
                            'start_makespan','end_makespan','s0','gain','improved','queries','decodes',
                            'wall_seconds','termination_reason')} | {'split':split,'branch_seed':seed})
    outcomes = []
    for (name,action), rows in sorted(by_instance_action.items()):
        metadata = manifest['instances'][name]
        outcomes.append(dict(split=split, instance=name, family=metadata['family'],
            operations=metadata['operations'], size_group=size_group(metadata['operations']), action=action,
            branches=len(rows), improved_branches=sum(r['improved'] for r in rows),
            improvement_rate=mean(float(r['improved']) for r in rows),
            mean_gain_s0=mean(r['gain'] for r in rows),
            mean_queries=mean(r['queries'] for r in rows), total_queries=sum(r['queries'] for r in rows),
            mean_decodes=mean(r['decodes'] for r in rows), total_decodes=sum(r['decodes'] for r in rows),
            mean_action_wall_seconds=mean(r['wall_seconds'] for r in rows),
            sum_action_wall_seconds=sum(r['wall_seconds'] for r in rows),
            query_cap_returns=sum(r['termination_reason']=='query_cap' for r in rows)))
    main_costs = dict(split=split, trajectories=len(trajectories),
        main_queries=sum(r['main_queries'] for r in trajectories),
        main_decodes=sum(r['main_decodes'] for r in trajectories),
        diagnostic_queries=sum(r['diagnostic_queries'] for r in trajectories),
        diagnostic_decodes=sum(r['diagnostic_decodes'] for r in trajectories),
        sum_main_wall_excluding_initialization_and_diagnostics=sum(r['main_wall_seconds_excluding_diagnostics'] for r in trajectories),
        sum_diagnostic_outer_wall_seconds=sum(r['diagnostic_seconds'] for r in trajectories))
    require(main_costs['diagnostic_queries'] == sum(r['queries'] for r in branches) and
            main_costs['diagnostic_decodes'] == sum(r['decodes'] for r in branches), 'Diagnostic costs do not reconcile')
    return outcomes, branch_rows, main_costs


def neutral_quality(split, trajectories, manifest):
    groups = defaultdict(list)
    for trajectory in trajectories:
        groups[trajectory['instance']].append(trajectory)
    output = []
    for name in manifest['splits'][split]:
        rows = groups[name]
        reference = manifest['instances'][name]['catalogue_reference']
        require(reference and reference > 0, 'A neutral descriptive catalogue reference is missing')
        aucs = []
        for row in rows:
            trace, end = row['main_incumbent_trace'], row['main_queries']
            require(trace and trace[0]['query']==1, 'Neutral Anytime trace does not start at query1')
            area, previous_query, previous_cost = 0.,0,math.inf
            for index,item in enumerate(trace):
                q,cost = item['query'],item['makespan']
                require(previous_query<q<=end and cost<=previous_cost, 'Invalid neutral incumbent trace')
                next_q=trace[index+1]['query'] if index+1<len(trace) else end+1
                area += (min(next_q,end+1)-q)*100.*(cost/reference-1)
                previous_query,previous_cost=q,cost
            aucs.append(area/end)
        best=min(row['main_final_makespan'] for row in rows)
        avg=mean(row['main_final_makespan'] for row in rows)
        output.append(dict(split=split,instance=name,family=manifest['instances'][name]['family'],
            operations=manifest['instances'][name]['operations'],runs=len(rows),
            catalogue_reference=reference,best_makespan=best,mean_makespan=avg,
            best_gap_percent=100.*(best/reference-1),mean_gap_percent=100.*(avg/reference-1),
            mean_actual_query_anytime_gap_percent=mean(aucs),mean_actual_queries=mean(r['main_queries'] for r in rows),
            meaning='neutral GA+periodic LS only; historical catalogue reference; not new-Agent results'))
    return output


def generate(args):
    manifest_path = ROOT/'projects/experiments/fp_v2_manifest.json'
    manifest, m1, review = read(manifest_path), read(args.m1), read(args.method_review)
    exposure = read(ROOT/manifest['exposure_audit'])
    protocol = read(ROOT/'projects/experiments/fp_v2_m2_protocol.json')
    require(m1['status']=='PASS' and m1['legacy_default_unchanged'], 'M1 compatibility evidence missing')
    require(review['status'].startswith('PASS'), 'Independent method review is missing or failed')
    require(sha(manifest_path)==protocol['manifest_sha256'], 'M2 protocol manifest identity mismatch')
    dev, val = read(args.development_analysis), read(args.validation_analysis)
    require(dev['stage']=='development' and val['stage']=='validation', 'Both complete analysis stages are required')
    require(val['selection_sha256']==sha(args.development_analysis), 'Validation did not use this frozen development selection')
    require(dev['selected_config']==val['selected_config'], 'Validation changed the selected model configuration')
    require(len(dev['configurations'])==4 and dev['configuration_grid']==protocol['selection']['four_configs'],
            'Development finite configuration grid changed')
    for analysis in (dev,val):
        for source,expected in analysis['source_sha256'].items():
            path=Path(source) if Path(source).is_absolute() else ROOT/source
            require(sha(path)==expected, f'Analysis source changed after results: {source}')
    cohorts={}
    for split,directory,receipt in [('development',args.development_data,args.development_audit),
                                    ('validation',args.validation_data,args.validation_audit)]:
        cohorts[split]=load_cohort(directory,receipt,split,manifest)
    dev_rows=cohorts['development'][1]
    require(canonical(dev_rows,ensure_ascii=False)==dev['development_identity'],
            'Development data differs from model-selection data')
    selected=dev['configurations'][dev['selected_config_index']]
    require(selected['config']==dev['selected_config'], 'Selected development configuration index mismatch')
    verify_predictions(selected['summary'],selected['predictions'],dev_rows,manifest['splits']['development'])
    verify_predictions(val['summary'],val['predictions'],cohorts['validation'][1],manifest['splits']['validation'])
    for config in dev['configurations']:
        verify_predictions(config['summary'],config['predictions'],dev_rows,manifest['splits']['development'])
    for stage in (selected,val):
        require(len(stage['dynamics_summary']['comparisons'])==6 and
                len(stage['dynamics_summary']['macro_errors'])==3,'Incomplete dynamics comparison family')
    suite=Path(args.tests).read_text()
    matches=re.findall(r'Ran (\d+) tests? in',suite)
    require(matches and int(matches[-1])>=64 and suite.rstrip().endswith('OK'),
            'The required complete 64-test suite has not passed')
    locked=set(manifest['splits']['locked_test'])
    for directory in (ROOT/'results').glob('fp_v2*'):
        if directory.is_dir():
            require(not any(any(p.name.startswith(name+'_') for name in locked) for p in directory.glob('*.json')),
                    'A locked-test search artifact exists; M2-only report cannot claim unrun')
    require(len(locked)==20 and not locked & set(sum([manifest['splits'][s] for s in ('development','validation')],[])),
            'Locked test membership is invalid')
    gate=val['m2_gate']; comparisons=val['summary']['comparisons']
    def passes(row):
        return row['mean_difference']>0 and row['hierarchical_bootstrap_95ci'][0]>0 and row['holm_p']<.05
    expected_pass=all(passes(r) for r in comparisons if r['metric']=='selected_gain' or
                      (r['comparator']=='B' and r['metric'] in ('ap','brier')))
    require(bool(gate['pass'])==expected_pass and gate['status'] in ('PASS','STOP_M3'),
            'Saved M2 gate disagrees with its frozen decision rule')
    require(not dev['m2_gate']['pass'], 'Development must not authorize M3')
    # Everything above is read-only; incomplete inputs cannot leave a final report.
    appendix=Path(args.appendix_dir); appendix.mkdir(parents=True,exist_ok=True)
    per_instance=[]; outcomes=[]; branches=[]; costs=[]; neutral=[]
    for split,analysis in [('development',selected),('validation',val)]:
        trajectories,rows,_,_=cohorts[split]
        per_instance.extend(instance_metrics(split,analysis['summary'],manifest))
        action,raw,cost=cost_and_action_rows(split,trajectories,rows,manifest)
        outcomes.extend(action);branches.extend(raw);costs.append(cost)
        neutral.extend(neutral_quality(split,trajectories,manifest))
    subgroup=grouped_metrics(per_instance)
    dev_grid=[]
    for config in dev['configurations']:
        for variant in VARIANTS:
            dev_grid.append(dict(config_index=config['config_index'],**config['config'],variant=variant,
                selected=config['config_index']==dev['selected_config_index'],
                **config['summary']['macro_instance_trajectory_metrics'][variant]))
    per_instance_comparisons=[]
    for split,analysis in [('development',selected),('validation',val)]:
        for comparison in analysis['summary']['comparisons']:
            for instance,effect in comparison['instance_differences'].items():
                per_instance_comparisons.append(dict(split=split,instance=instance,candidate='E',
                    comparator=comparison['comparator'],metric=comparison['metric'],
                    positive_favors_E=True,effect=effect))
    locked_rows=[dict(instance=name,status='NOT_RUN_M2_LOCK',operations=manifest['instances'][name]['operations'],
                      raw_sha256=manifest['instances'][name]['raw_sha256']) for name in manifest['splits']['locked_test']]
    appendices={'per_instance_prediction_metrics.csv':per_instance,'subgroup_prediction_metrics.csv':subgroup,
        'per_instance_action_outcomes_and_costs.csv':outcomes,'all_branch_outcomes_and_seeds.csv':branches,
        'neutral_trajectory_quality.csv':neutral,'development_all_configurations.csv':dev_grid,
        'per_instance_primary_effects.csv':per_instance_comparisons,'aggregate_costs.csv':costs,
        'locked_test_status.csv':locked_rows}
    for filename,rows in appendices.items():csv_write(appendix/filename,rows)
    output=Path(args.output); output.parent.mkdir(parents=True,exist_ok=True)
    def link(path):
        import os
        return os.path.relpath(Path(path).resolve(),output.parent.resolve())
    lines=['# FP Agent v2：动作条件化动力学与独立证据报告','',
        '本报告由完整冻结结果和独立数据审计生成；不运行求解器、重选配置或重新计算显著性。预算仅作公平性与成本条件。', '',
        f"**M1：PASS；M2：{gate['status']}；M3：NOT_RUN。**",'']
    if not gate['pass']:
        lines += ['**本轮独立验证未达到预定的 FP 增量信息与实际动作收益联合门槛。按停止条件，不实现 M3，不运行锁定20例，不建议继续本轮动作条件化 FP 方法路线。**',
                  '该结论限定于冻结模型、特征、动作强度和数据，不证明所有 FP 方法无效，也不把不显著解释为等价。','']
    else:
        lines += ['独立 M2 达到允许进入 M3 的门槛；当前仍只有离线反事实证据，正式七臂闭环与未见测试尚未完成，不能宣称新 Agent 已改善 Gap 或投稿就绪。','']
    lines += ['## 1. 语义、历史与完整性','',
        f"旧 Fixed/Stagnation/Agent-NoFP/Agent-FP 的8条修改前后回归完全一致；旧源码快照独立重放为 {m1['legacy_regression']['standalone_old_snapshot_replay']}。类型接口区分真实代数与观测计数，500/1000/2000工序的指定12代门槛可达。当前完整测试日志为{int(matches[-1])}项通过；测试通过不代表方法有效。",'',
        f"四份阶段报告已恢复；来源清单完整读入498份相关MD/DOCX及29份上传文本，其中9份相关。历史3A/3B、v2、成本研究与旧Q/T数据全部按曝光重新分组，合并{len(exposure['exposed_instances'])}个暴露/保守保留排除标识。详见[暴露审计](fp_agent_exposure_audit.md)、[语义审计](fp_agent_semantic_audit.md)及[实际方法](fp_agent_method_v2.md)。",'',
        table(['分组','实例','轨迹/20种子','保存状态','诊断分支','快照/分支DAG核验'],
            [[split,len(manifest['splits'][split]),len(cohorts[split][0]),len(cohorts[split][0])*9,
              len(cohorts[split][1]),f"{cohorts[split][3]['counts']['snapshot_DAG_checks']}/{cohorts[split][3]['counts']['branch_DAG_checks']}"]
             for split in ('development','validation')]),
        '开发320条、验证240条，共560条主轨迹、5,040个保存状态、30,240个独立动作分支。每状态三动作各两重复；所有run_index=0..19完整保留，未按结果删实例/种子/无改善行。重复仅在动力学拟合中折叠，推断以实例为单位。审计对完整起点NPZ重算状态/指纹，对全部分支最好染色体独立DAG重算；终点完整种群未保存，因此终点mean/std/diversity依赖冻结runner，不能称独立全种群重验。','',
        '## 2. 四个开发配置与独立验证','',
        '开发整实例外层OOF的E Brier最小配置用于所有特征组；内层整实例OOF构造训练FP特征。新验证不再选参。开发选择分数有选择偏差，正式门槛只看12个新验证实例。','',
        table(['配置','ridge','L2','E AP','E Brier','E所选收益/s0百分点','B所选收益/s0百分点','选中'],
            [[c['config_index'],c['config']['ridge'],c['config']['l2'],
              number(c['summary']['macro_instance_trajectory_metrics']['E']['ap']),
              number(c['summary']['macro_instance_trajectory_metrics']['E']['brier']),
              number(100*c['summary']['macro_instance_trajectory_metrics']['E']['selected_gain']),
              number(100*c['summary']['macro_instance_trajectory_metrics']['B']['selected_gain']),
              c['config_index']==dev['selected_config_index']] for c in dev['configurations']]),
        f"选中配置：{json.dumps(dev['selected_config'],ensure_ascii=False)}；验证绑定的选择文件SHA256为 `{val['selection_sha256']}`。全部4×7配置/特征组指标保存在[开发完整表]({link(appendix/'development_all_configurations.csv')})。",'',
        'A为停滞+多样性；B加其余四维状态；C加原统一FP；D加动作残差/差异；E再加OOF误差/可靠性；二阶普通状态与随机训练池FP整块重分配为对照。所有组都有相同的阶段、此前6代真实主收益上下文和同一logistic/L-BFGS架构。随机负对照使用有放回重分配，非严格无放回置换。','']
    for split,analysis in [('development',selected),('validation',val)]:
        macro=analysis['summary']['macro_instance_trajectory_metrics']
        lines += [f'### {split}：全部特征组','',
            table(['组','AP','Brier↓','动作收益/s0百分点','动作收益秩相关','相对B决策变化/%'],
                [[v,number(macro[v]['ap']),number(macro[v]['brier']),number(100*macro[v]['selected_gain']),
                  number(macro[v]['action_rank']),number(100*macro[v]['decision_change_vs_B'],3)] for v in VARIANTS]),
            f"无正事件主轨迹：{analysis['summary']['no_positive_event_trajectories']}/{analysis['summary']['trajectories']}；按冻结约定其AP=0。",'']
    lines += ['## 3. 主要九项配对比较与停止判断','',
        '效应统一为正有利E；Brier为对照−E，AP/所选收益为E−对照。所选收益和其区间乘100后单位为s0百分点，AP/Brier不乘100。实例等权，轨迹嵌套配对；95%CI为10,000次实例→配对轨迹bootstrap边际区间，不是多重校正同时区间。所有九项在同一Holm族，精确Wilcoxon用实例均值差；rank-biserial为带方向效应量。','',
        table(['对照','指标','效应','95%CI','原p','共同Holm p','rank-biserial','实例胜/平/负','门槛单项'],
            [[r['comparator'],r['metric'],number(r['mean_difference']*(100 if r['metric']=='selected_gain'else 1)),
              '['+', '.join(number(v*(100 if r['metric']=='selected_gain'else 1))for v in r['hierarchical_bootstrap_95ci'])+']',
              number(r['p'],8),number(r['holm_p'],8),number(r['rank_biserial'],4),
              '/'.join(map(str,r['instance_win_tie_loss'])),'通过'if passes(r)else'未通过']for r in comparisons]),
        f"预定联合门槛：实际收益胜三个对照={gate['positive_action_gain_vs_all_controls']}；AP与Brier同时胜B={gate['incremental_prediction_information_vs_B']}。最终状态 `{gate['status']}`。不以单一较好的点估计、单个未校正p或D的结果替代门槛。",'']
    for split,analysis in [('development',selected),('validation',val)]:
        dynamics=analysis['dynamics_summary']
        lines += [f'## 4. {split} 状态预测与全部六项误差对照','',
            table(['动作','动作条件误差','忽略动作统一误差','恒等误差','可用率','分支数'],
                [[r['action'],number(r['action_error']),number(r['unified_one_action_error']),number(r['identity_error']),
                  number(r['ready_fraction']),r['records']]for r in dynamics['macro_errors']]),
            table(['动作','误差对照','误差减少/正有利条件化','95%CI','原p','独立六项Holm p','rank-biserial'],
                [[r['action'],r['comparator'],number(r['mean_error_reduction']),
                  '['+', '.join(number(v)for v in r['hierarchical_bootstrap_95ci'])+']',number(r['p'],8),
                  number(r['holm_p'],8),number(r['rank_biserial'],4)]for r in dynamics['comparisons']]),
            '此处统一对照是把纯单动作转移合并并忽略动作身份的新模型，区别于原始每5代、可能混合GA/LS的旧统一算子；后者以C组保留。六项误差族与决策九项族分开，不控制所有终点的联合错误率。状态预测好也不自动证明改善动作选择。','']
    lines += ['## 5. 跨实例族、规模和逐实例动作证据','',
        '以下分组为完整描述，不作事后子组检验或挑选有利组。规模分箱在查看本轮结果前固定为≤100、101–400、>400工序。每个子组先实例内平均再实例等权；小家族分组不能证明跨族稳定性。','']
    group_index={(r['split'],r['group_type'],r['group'],r['variant']):r for r in subgroup}
    group_rows=[]
    for split,kind,group in sorted({(r['split'],r['group_type'],r['group'])for r in subgroup}):
        b=group_index[split,kind,group,'B']; e=group_index[split,kind,group,'E']
        group_rows.append([split,kind,group,e['instances'],number(e['ap']-b['ap']),number(b['brier']-e['brier']),
            number(100*(e['selected_gain']-b['selected_gain'])),number(100*e['decision_change_vs_B'],2)])
    lines += [table(['分组','类型','组别','实例数','E−B AP','B−E Brier','E−B收益/s0百分点','决策变化/%'],group_rows)]
    instance_index={(r['split'],r['instance'],r['variant']):r for r in per_instance}
    lines += [table(['验证实例','家族/工序','E−B AP','B−E Brier','E−B收益/s0百分点','决策变化/%','E GA/LS/VND选择次数'],
        [[name,f"{manifest['instances'][name]['family']}/{manifest['instances'][name]['operations']}",
          number(instance_index['validation',name,'E']['ap']-instance_index['validation',name,'B']['ap']),
          number(instance_index['validation',name,'B']['brier']-instance_index['validation',name,'E']['brier']),
          number(100*(instance_index['validation',name,'E']['selected_gain']-instance_index['validation',name,'B']['selected_gain'])),
          number(100*instance_index['validation',name,'E']['decision_change_vs_B'],2),
          '/'.join(str(instance_index['validation',name,'E'][f'chosen_{a}'])for a in ACTIONS)]for name in manifest['splits']['validation']]),
        f"所有28实例×7组完整指标见[逐实例全表]({link(appendix/'per_instance_prediction_metrics.csv')})；所有九项逐实例效应见[完整配对效应]({link(appendix/'per_instance_primary_effects.csv')})；所有家族/规模×7组见[分组全表]({link(appendix/'subgroup_prediction_metrics.csv')})。",'',
        '## 6. 动作实际改善与计算成本','',
        table(['分组','动作','分支','改善数','实例宏改善率','平均收益/s0百分点','平均请求','平均解码','平均动作秒','到500上限次数'],
            [[split,a,sum(r['branches']for r in outcomes if r['split']==split and r['action']==a),
              sum(r['improved_branches']for r in outcomes if r['split']==split and r['action']==a),
              number(mean(r['improvement_rate']for r in outcomes if r['split']==split and r['action']==a)),
              number(100*mean(r['mean_gain_s0']for r in outcomes if r['split']==split and r['action']==a)),
              number(mean(r['mean_queries']for r in outcomes if r['split']==split and r['action']==a),2),
              number(mean(r['mean_decodes']for r in outcomes if r['split']==split and r['action']==a),2),
              number(mean(r['mean_action_wall_seconds']for r in outcomes if r['split']==split and r['action']==a)),
              sum(r['query_cap_returns']for r in outcomes if r['split']==split and r['action']==a)]
             for split in ('development','validation')for a in ACTIONS]),
        table(['分组','主轨迹请求/解码','诊断请求/解码','累计主轨迹秒（不含初始化/诊断）','累计诊断外围秒'],
            [[r['split'],f"{r['main_queries']}/{r['main_decodes']}",f"{r['diagnostic_queries']}/{r['diagnostic_decodes']}",
              number(r['sum_main_wall_excluding_initialization_and_diagnostics'],3),number(r['sum_diagnostic_outer_wall_seconds'],3)]for r in costs]),
        '统一窗口为一次原子调用；三动作的实际查询/时间不同，不能把同一次动作机会写成同墙钟效率。请求在cache前计费；解码含计量上下文内结构解码，不等于uncached objective evaluations。分支wall从setup后起表、在端点统计/独立验证前结束；diagnostic外围wall包括复制和尾验。主wall在初始化后起表，但主请求/解码含初始化。累计任务wall在并行执行时不等于整批主机elapsed，也不是完整端到端成本。',
        f"每实例三动作改善率与成本见[完整动作表]({link(appendix/'per_instance_action_outcomes_and_costs.csv')})；全部30,240分支与实际派生种子见[分支与种子]({link(appendix/'all_branch_outcomes_and_seeds.csv')})。所有run_index和两个重复均保留；并列选择按GA→LS→VND，不选事后更优的重复。",'',
        '## 7. 中性主轨迹质量参考：不是新Agent结果','',
        '下表仅是生成同状态诊断数据的GA+周期LS中性轨迹，全部特征组读取同一批轨迹，不能据此比较新Agent。Gap用冻结JSPLIB catalogue历史参照，不宣称最新BKS、认证最优性或整体SOTA。Anytime为查询1至该条轨迹实际最后查询的incumbent Gap离散均值；180代相同不保证查询/墙钟相同，没有外推或补算统一预算。Best为预定20种子中最小终值，Mean为全部20终值均值。','',
        table(['分组','实例','历史参照','Best/Mean makespan','Best Gap/%','Mean Gap/%','实际查询Anytime Gap/%','平均实际请求'],
            [[r['split'],r['instance'],r['catalogue_reference'],f"{r['best_makespan']}/{number(r['mean_makespan'],2)}",
              number(r['best_gap_percent'],3),number(r['mean_gap_percent'],3),
              number(r['mean_actual_query_anytime_gap_percent'],3),number(r['mean_actual_queries'],1)]for r in neutral]),
        f"[全部中性质量数据]({link(appendix/'neutral_trajectory_quality.csv')})；不计算七种新Agent的Gap差或由该表反推FP有效性。",'',
        '## 8. 失败保留、识别边界与投稿准备度','',
        'v1 schema smoke曾在写NPZ后因相对输出路径序列化失败，原pilot保留；正式开发前仅修路径工程问题并通过v2 smoke/独立审计，没有按Gap换参。正式两cohort由PASS_COMPLETE网格审计约束，不缺行、不按无改善删除。无正例轨迹AP=0并显式计数；动作rank在恒定分数/收益时按冻结约定记0，不能解释为有效Spearman估计。',
        '当前FP信号是发展历史拟合映射对四维x的确定性变换；相对线性B的变化可能是非线性表示、训练先验或可靠性/外推信息。预测状态变化小不是局部最优，动作差异大不是makespan收益。经验仿射图不提供全局收敛保证。离线诊断取得全部动作标签的成本不是部署免费信息；模型未影响主轨迹，任何离线决策变化都不等于闭环搜索收益。','']
    if not gate['pass']:
        failed=[f"{r['comparator']}/{r['metric']}"for r in comparisons if
                (r['metric']=='selected_gain' or(r['comparator']=='B'and r['metric']in('ap','brier')))and not passes(r)]
        lines += [f"本次没有通过的必要项：{', '.join(failed)}。不依靠家族子组、某一动作状态误差或未校正p挽回主张。",'',
            '**投稿准备度：NOT_READY_FOR_FP_AGENT_METHOD_SUBMISSION。** 动作条件化建模的局部状态误差结果按上表限定报告；FP在共同评分架构中的可靠独立动作收益条件未全部建立，正式未见实例闭环证据未产生。三项拟议主要贡献不能同时写成得到验证。按用户停止条件止于M2，不自动提出第四轮或第五轮开放式探索。','']
    else:
        lines += ['**投稿准备度：M2_PASS_M3_REQUIRED。** 离线门槛已满足，但新Agent、七臂正式性能与锁定测试未完成，目前不能将三项拟议贡献全部写成成立。','']
    agent_names=['Legacy Agent-FP（本轮新正式矩阵）','Semantic-Fixed Agent-NoFP','Semantic-Fixed Agent+OriginalFP',
                 'State-Only Agent','State+Action-Conditioned FP Agent','同架构移除FP','同架构随机FP负对照']
    lines += [table(['正式Agent对照','本轮状态'],[[name,'NOT_RUN']for name in agent_names]),
        '旧Fixed、Stagnation、Agent-NoFP、Legacy Agent-FP及显式语义基线的原runner/快照仍可独立运行。上表NOT_RUN指本轮新的共同七臂正式性能矩阵，不抹去旧实验和M1回归；离线A–E不是这七臂。外部强JSSP算法的旧Q/T参照继续保留，不把其预算或求解质量混入本轮机制检验。','',
        f"20例锁定测试全部NOT_RUN，逐ID及输入hash见[锁定状态]({link(appendix/'locked_test_status.csv')})。M2入口仅允许development/validation；在本轮声明的fp_v2结果目录没有发现锁定测试搜索记录。未把静态输入检查写成已运行质量测试。",'',
        '## 9. 可复现输入与审计链','',
        f"开发数据独立审计：[receipt]({link(args.development_audit)})；验证数据独立审计：[receipt]({link(args.validation_audit)})；[方法独立复核]({link(args.method_review)})；[完整测试日志]({link(args.tests)})。",'',
        f"冻结原始结果：`{Path(args.development_data).resolve().relative_to(ROOT)}`、`{Path(args.validation_data).resolve().relative_to(ROOT)}`。对应完整分析：[开发]({link(args.development_analysis)})、[验证]({link(args.validation_analysis)})。模型A/c、全部OOF误差、七组概率与优化器诊断均在分析JSON中，不以图表代替可复核数值。",'',
        '生成器只读取以上数据与保存统计：','',
        '```sh',f'python3 scripts/report_fp_agent_v2.py --development-audit {args.development_audit} \\',
        f'  --validation-audit {args.validation_audit}','```','',
        f"来源和导出SHA256见[报告生成清单]({link(args.receipt)})。论文方法见[fp_agent_method_v2.md](fp_agent_method_v2.md)。"]
    output.write_text('\n'.join(lines)+'\n')
    inputs=[manifest_path,ROOT/manifest['exposure_audit'],ROOT/'projects/experiments/fp_v2_m2_protocol.json',
        Path(args.development_analysis),Path(args.validation_analysis),Path(args.development_audit),
        Path(args.validation_audit),Path(args.m1),Path(args.method_review),Path(args.tests)]
    exports=[output]+[appendix/name for name in appendices]
    receipt={'status':'COMPLETE_AUDITED_REPORT','created_utc':datetime.now(timezone.utc).isoformat(),
        'builder_sha256':sha(__file__),'M2_gate':gate,'M3_status':'NOT_RUN',
        'solver_calls_by_builder':0,'inferential_statistics_recomputed':False,
        'input_sha256':{str(p.resolve().relative_to(ROOT)):sha(p)for p in inputs},
        'output_sha256':{str(p.resolve().relative_to(ROOT)):sha(p)for p in exports},
        'denominators':dict(development_trajectories=320,validation_trajectories=240,
            saved_states=5040,diagnostic_branches=30240,locked_test_instances_unrun=20)}
    Path(args.receipt).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--development-analysis',default=ROOT/'projects/analysis/fp_v2_development_analysis.json',type=Path)
    parser.add_argument('--validation-analysis',default=ROOT/'projects/analysis/fp_v2_validation_analysis.json',type=Path)
    parser.add_argument('--development-data',default=ROOT/'results/fp_v2_development',type=Path)
    parser.add_argument('--validation-data',default=ROOT/'results/fp_v2_validation',type=Path)
    parser.add_argument('--development-audit',required=True,type=Path)
    parser.add_argument('--validation-audit',required=True,type=Path)
    parser.add_argument('--m1',default=ROOT/'projects/analysis/fp_semantic_m1_verification.json',type=Path)
    parser.add_argument('--method-review',default=ROOT/'projects/analysis/fp_action_method_review.json',type=Path)
    parser.add_argument('--tests',default=ROOT/'projects/analysis/fp_v2_unittest.log',type=Path)
    parser.add_argument('--output',default=ROOT/'projects/docs/fp_agent_evidence_report.md',type=Path)
    parser.add_argument('--appendix-dir',default=ROOT/'projects/analysis/fp_v2_report',type=Path)
    parser.add_argument('--receipt',default=ROOT/'projects/analysis/fp_v2_report_manifest.json',type=Path)
    args=parser.parse_args()
    result=generate(args)
    print(json.dumps({'status':result['status'],'gate':result['M2_gate'],'report':str(args.output)},ensure_ascii=False))


if __name__=='__main__':
    main()
